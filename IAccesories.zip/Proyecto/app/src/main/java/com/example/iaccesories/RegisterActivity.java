package com.example.iaccesories;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private Button mBregistre;
    private FirebaseUser mUsuariActual;

    private EditText mNomUsuari;
    private EditText mETemail;
    private EditText mETpassword;
    private FirebaseDatabase database = FirebaseDatabase.getInstance("https://iaccesories-7300a-default-rtdb.europe-west1.firebasedatabase.app/");
    private DatabaseReference myRef = database.getReference();
    private TextView mTVlogin;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mNomUsuari = findViewById(R.id.ET_NomUsuari);
        mETemail = findViewById(R.id.ET_email);
        mETpassword = findViewById(R.id.ET_password);
        mBregistre = findViewById(R.id.BT_registe);
        mAuth = FirebaseAuth.getInstance();
        mTVlogin = findViewById(R.id.TV_login);

        mTVlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        mBregistre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomUsuari = mNomUsuari.getText().toString();
                String email = mETemail.getText().toString();
                String password = mETpassword.getText().toString();

                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                Usuari usuari = new Usuari();

                                usuari.setNombreUsuario(nomUsuari);
                                usuari.setEmail(email);
                                usuari.setIdUsuario(mAuth.getUid());
                                usuari.setTipoUsuario("usuari");

                                myRef.child("usuari").child(mAuth.getUid()).setValue(usuari);

                                Intent intent = new Intent(RegisterActivity.this, PantallaPrincipal.class);
                                startActivity(intent);
                                Intent intent2 = new Intent(RegisterActivity.this, LoginActivity.class);
                                startActivity(intent2);
                            }
                        })

                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Toast.makeText(getApplicationContext(), "Ha habido un error en la base de datos", Toast.LENGTH_SHORT).show();

                            }
                        });
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        mUsuariActual = mAuth.getCurrentUser();
        if(mUsuariActual != null) {
            //Intent intent = new Intent(RegisterActivity.this, PantallaPrincipal.class);
            //startActivity(intent);
        }
    }
}